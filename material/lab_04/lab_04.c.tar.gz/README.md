<div align="justify" style="margin-right:25px;margin-left:25px">

# Laboratoire 4 : Développement de drivers kernel-space <!-- omit in toc -->

# Auteur <!-- omit in toc -->

- Urs Behrmann

# Table des matières <!-- omit in toc -->

- [Exercice 1](#exercice-1)
- [Exercice 2](#exercice-2)

# Exercice 1



# Exercice 2



</div>